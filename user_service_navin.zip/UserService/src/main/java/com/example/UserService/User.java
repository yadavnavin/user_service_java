package com.example.UserService;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {
    @Id
    @Column(name = "uid")
    private int uid;

    @Column(name = "uname")
    private String userName;

    @Column(name = "address")
    private String userAddress;

    @Column(name = "dob")
    private String userDob;

    @Column(name = "degree")
    private String userDegree;

    @Column(name = "branch")
    private String userBranch;

    @Column(name = "cgpa")
    private float userCgpa;

    @Column(name = "puc")
    private float userPuc;

    @Column(name = "sslc")
    private float userSslc;

    @Column(name = "yop")
    private int userYop;

    @Column(name = "skills")
    private String userSkills;

    // Constructors
    public User() {
        super();
    }

    public User(int uid, String userName, String userAddress, String userDob, String userDegree, String userBranch,
                float userCgpa, float userPuc, float userSslc, int userYop, String userSkills) {
        this.uid = uid;
        this.userName = userName;
        this.userAddress = userAddress;
        this.userDob = userDob;
        this.userDegree = userDegree;
        this.userBranch = userBranch;
        this.userCgpa = userCgpa;
        this.userPuc = userPuc;
        this.userSslc = userSslc;
        this.userYop = userYop;
        this.userSkills = userSkills;
    }

    // Getters and Setters
    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserDob() {
        return userDob;
    }

    public void setUserDob(String userDob) {
        this.userDob = userDob;
    }

    public String getUserDegree() {
        return userDegree;
    }

    public void setUserDegree(String userDegree) {
        this.userDegree = userDegree;
    }

    public String getUserBranch() {
        return userBranch;
    }

    public void setUserBranch(String userBranch) {
        this.userBranch = userBranch;
    }

    public float getUserCgpa() {
        return userCgpa;
    }

    public void setUserCgpa(float userCgpa) {
        this.userCgpa = userCgpa;
    }

    public float getUserPuc() {
        return userPuc;
    }

    public void setUserPuc(float userPuc) {
        this.userPuc = userPuc;
    }

    public float getUserSslc() {
        return userSslc;
    }

    public void setUserSslc(float userSslc) {
        this.userSslc = userSslc;
    }

    public int getUserYop() {
        return userYop;
    }

    public void setUserYop(int userYop) {
        this.userYop = userYop;
    }

    public String getUserSkills() {
        return userSkills;
    }

    public void setUserSkills(String userSkills) {
        this.userSkills = userSkills;
    }

    // Override toString method for better readability
    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", userName='" + userName + '\'' +
                ", userAddress='" + userAddress + '\'' +
                ", userDob='" + userDob + '\'' +
                ", userDegree='" + userDegree + '\'' +
                ", userBranch='" + userBranch + '\'' +
                ", userCgpa=" + userCgpa +
                ", userPuc=" + userPuc +
                ", userSslc=" + userSslc +
                ", userYop=" + userYop +
                ", userSkills='" + userSkills + '\'' +
                '}';
    }
}
